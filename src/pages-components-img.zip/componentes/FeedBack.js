import React, { useState } from 'react';
import BasicRating from './Rating';

function Comentario(props) {
  const [mostrarMas, setMostrarMas] = useState(false);
  const [comentarioVisible, setComentarioVisible] = useState(true); // Agregamos una variable de estado

  const toggleMostrarMas = () => {
    setMostrarMas(!mostrarMas);
  };

  const toggleComentario = () => {
    setComentarioVisible(!comentarioVisible); // Cambia la visibilidad del comentario
  };

  return (
    <div style={{ background: 'lightblue', padding: '20px', width: '80%', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'left' }}>{props.nombreUsuario}</div>
        <div style={{ textAlign: 'right' }}>{props.fecha}</div>
      </div>
      {comentarioVisible && ( // Verificamos si el comentario está visible
        <p>
          {mostrarMas || props.comentario.length <= 100 ? props.comentario : `${props.comentario.slice(0, 100)}...`}
        </p>
      )}
      {props.comentario.length > 100 && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={toggleMostrarMas}>
            {mostrarMas ? 'Menos' : 'Más'}
          </button>
        </div>
      )}
      {props.isLoggedIn && (
        <div style={{ textAlign: 'right'}}>
          <button onClick={toggleComentario}>
            {comentarioVisible ? 'Ocultar Comentario' : 'Mostrar Comentario'}
          </button>
        </div>
      )}
      <div style={{ textAlign: 'right' }}>
        <BasicRating />
      </div>
    </div>
  );
}

export default Comentario;
